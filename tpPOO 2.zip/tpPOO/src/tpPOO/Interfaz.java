package tpPOO;

public class Interfaz {
	public void AccederAlCatalogo() {
		
	}
	public void VerificarProducto() {
		
	}
	public void MostrarProducto() {
		
	}
	public void VerificarMetodoDePago() {
		
	}
	
	

}
