package tpPOO;

public class Debito {
	private int Monto;

	public int getMonto() {
		return Monto;
	}

	public void setMonto(int monto) {
		this.Monto = monto;
	}

	public Debito(int monto) {
		Monto = monto;
	}
	
	

}
