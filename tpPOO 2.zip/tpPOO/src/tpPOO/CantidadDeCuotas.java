package tpPOO;

public enum CantidadDeCuotas {
	UNO, DOS, TRES, SEIS

}
